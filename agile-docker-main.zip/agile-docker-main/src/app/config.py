SQLALCHEMY_DATABASE_URL = 'postgresql+psycopg2://postgres:postgres@gile@db:5432/consultorio'
JWT_SECRET = '31235517]#@!$%J3HKNJ2NK3LK213123LBJH213'