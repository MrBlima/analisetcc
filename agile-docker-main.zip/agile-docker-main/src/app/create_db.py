import model.model, os, subprocess
from sqlalchemy import create_engine
from sqlalchemy.sql import text


engine = create_engine('postgresql+psycopg2://postgres:postgres@gile@db:5432/consultorio', connect_args={})
from model.model import Base

#subprocess.run(['sudo -u postgres PGPASSWORD=postgres psql -c "DROP DATABASE IF EXISTS consultorio"'], stdout=subprocess.PIPE, text=True, shell=True)
#subprocess.run(['sudo -u postgres PGPASSWORD=postgres psql -c "CREATE DATABASE consultorio"'], stdout=subprocess.PIPE, text=True, shell=True)


with engine.connect() as con:
    Base.metadata.create_all(engine)
    sample_address = text("""INSERT INTO address (id, street, neighborhood, number, city, state) VALUES (1, 'Rua das ametistas, Vila Mariana', 'Centro', '321', 'Cáceres', 'AL');""")
    sample_anamnese = text("""INSERT INTO anamnese (id, anamnese, clock_test, minemental, moca, date_update) VALUES (1, '%3Cp%3E%3Cbr%3E%3C/p%3E', 4, 2, 21, '2021-03-21');""")
    sample_patient = text("""INSERT INTO patient (id, public_id, name, birthday, state_civilian, cpf, rg, gender, "natural", phone, cellphone, mother, father, facebook, fk_address, fk_anamnese) VALUES (1, 'e5ee0a66-88bd-45b3-a4d3-1a0ff1910852', 'ANTÔNIO G B', '2000-10-23', 'Solteiro(a)', '067.284.531-80', '2313213     ', 'F', 'Cacerense', '(65)99681-2726', '(65)99681-2726', 'no', 'no', NULL, 1, 1);""")
    scheduling_type = text("""INSERT INTO public.scheduling_type (id, name) VALUES (1, 'Consulta'),(2, 'Retorno');""")
    insurance = text("""INSERT INTO insurance(name) VALUES ('PARTICULAR'),('FUSEX'),('UNIMED'),('PAX-SILVA'),('MULTI-VIDA'),('PARK-DOS IPÊS'),('PAX-MIRASSOL'),('PAX-VALE DO SOL'),('SINDICATO DOS TRABALHOS RURAIS'),('ASSOCIAÇÃO DE CABOS E SOLDADOS'),('ASSOCIAÇÃO DE CABOS E SOLDADOS'),('EM DOMICILIO');""")
    #con.execute(sample_address)
    #con.execute(sample_anamnese)
    #con.execute(sample_patient)
    con.execute(scheduling_type)
    con.execute(insurance)
    con.close()


#INSERT INTO address (id, street, neighborhood, number, city, state) VALUES (1, 'Rua das ametistas, Vila Mariana', 'Centro', '321', 'Cáceres', 'AL');
#INSERT INTO anamnese (id, anamnese, clock_test, minemental, moca, date_update) VALUES (1, '%3Cp%3E%3Cbr%3E%3C/p%3E', 4, 2, 21, '2021-03-21');
#INSERT INTO patient (id, public_id, name, birthday, state_civilian, cpf, rg, gender, "natural", phone, cellphone, mother, father, facebook, fk_address, fk_special_cares, fk_anamnese) VALUES (1, 'e5ee0a66-88bd-45b3-a4d3-1a0ff1910852', 'ANTÔNIO G B', '2000-10-23', 'Solteiro(a)', '067.284.531-80', '2313213     ', 'F', 'Cacerense', '(65)99681-2726', '(65)99681-2726', 'no', 'no', NULL, 1, 1, 1);
#INSERT INTO public.scheduling_type (id, name) VALUES (1, 'Consulta'),(2, 'Retorno');
#INSERT INTO public.scheduling_type (id, name) VALUES (2, 'Retorno');
#INSERT INTO insurance(name) VALUES ('PARTICULAR'),('FUSEX'),('UNIMED'),('PAX-SILVA'),('MULTI-VIDA'),('PARK-DOS IPÊS'),('PAX-MIRASSOL'),('PAX-VALE DO SOL'),('SINDICATO DOS TRABALHOS RURAIS'),('ASSOCIAÇÃO DE CABOS E SOLDADOS'),('ASSOCIAÇÃO DE CABOS E SOLDADOS'),('EM DOMICILIO');