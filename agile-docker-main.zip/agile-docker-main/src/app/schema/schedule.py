from pydantic import BaseModel, validator
from datetime import date
from datetime import datetime
from typing import Optional


class SchedulingIn(BaseModel):
    name: str
    phone: str
    fk_scheduling_type: int
    insurance: Optional[str]
    custom_insurance: Optional[str]
    date_hour: str
    is_confirmed: bool
    is_present: bool


    @validator('name')
    def nameUper(name):
        return name.title()
    
    class Config:
        orm_mode = True


class SchedulingEdit(BaseModel):
    id: int
    is_present: Optional[bool]
    is_confirmed: Optional[bool]

    class Config:
        orm_mode = True

class SchedulingOut(BaseModel):
    id: int
    name: str
    phone: str
    scheduling_type: str
    insurance: str
    hour: str
    is_confirmed: bool
    is_present: bool
    last_visit: str
    
    class Config:
        orm_mode = True

    @validator('hour')
    def toHour(cls, v):
        return v.split()[1][:-3]

    @validator('last_visit')
    def lastvist(cls, v):
        print(v)
        if '-' in v:
            v = datetime.strptime(v, "%Y-%m-%d").date()
            return v.strftime('%d/%m/%Y')
        else:
            return 'Primeira vez'


class SchedulingTypeIn(BaseModel):
    name: str

    class Config:
        orm_mode = True
