
from pydantic import BaseModel, validator
from app.schema.special_cares import SpecialCaresOut
from app.schema.anamnese import Anamnese
from typing import List, Optional
from datetime import date
from app.util import get_days



class Address(BaseModel):
    number: str
    street: str
    neighborhood: str
    city: str 
    state: str

    class Config:
        orm_mode = True

class SpecialCaresOutIn(BaseModel):
    allergic_substances : Optional[str]
    ortese: Optional[str]
    drugs: Optional[str]
    observations: Optional[str]
    
    class Config:
        orm_mode= True

class PatientIn(BaseModel):
    name: str
    birthday: date
    state_civilian: str
    cpf: str
    rg: str
    gender : str
    natural : str
    phone: str
    cellphone: str
    mother: str
    father: str
    address: Address
    

    class Config:
        orm_mode = True


class PatientEdit(BaseModel):
    name: str
    birthday: str
    state_civilian: str
    cpf: str
    rg: str
    gender : str
    natural : str
    phone: str
    cellphone: Optional[str]
    mother: str
    father: str
    address: Address
    special_cares: Optional[SpecialCaresOutIn]

    class Config:
        orm_mode = True

class QuickPatient(BaseModel):
    name: str
    phone: str

class BasePatient(BaseModel):
    public_id: str
    name: str
    phone: str
    birthday: Optional[date]
    address: Optional[Address]
    anamnese: Optional[Anamnese]

    class Config():
        orm_mode = True

    @validator('address')
    def complete(cls, v):
        if not v:
            v = " "
            return v
        else:
            return v

    @validator('birthday')
    def convertday(cls, v):
        if not v:
            v = " "
            return v
        return get_days(v)
    




class PatientOut(BaseModel):
    public_id: str
    name: str
    birthday: date
    cpf: str
    rg: str
    phone: str
    cellphone: str
    address: Address
    
    class Config:
        orm_mode = True

class PatientList(BaseModel):
    __root__: List[BasePatient]

    class Config:
        orm_mode = True


class PatientAll(BaseModel):
    name: str
    birthday: Optional[date]
    state_civilian: Optional[str]
    cpf: Optional[str]
    rg: Optional[str]
    gender: Optional[str]
    natural: Optional[str]
    phone: str
    cellphone: Optional[str]
    mother: Optional[str]
    father: Optional[str]
    address: Optional[Address]
    special_cares: Optional[SpecialCaresOutIn]
    #add agenda e anamnese caso precise
    
    class Config:
        orm_mode = True


    
    
    @validator('special_cares')
    def complete(cls,v):
        if not v:
            v = " "
            return v
        else:
            return v


    @validator('address')
    def completeAddr(cls, v):
        if not v:
            v = " "
            return v
        else:
            return v


class PatientAllDays(PatientAll):
    @validator('birthday')
    def getbirth(cls, v):
        if not v:
            v = " "
            return v
        return get_days(v)


        