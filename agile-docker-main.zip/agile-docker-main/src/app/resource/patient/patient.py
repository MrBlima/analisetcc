from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi_sqlalchemy import db
from app.schema.patient import (
    PatientIn,
    PatientEdit,
    PatientOut,
    PatientList,
    PatientAll,
    PatientAllDays,
    BasePatient,
)
from app.schema.anamnese import Anamnese
from app.auth.auth import get_current_user, Request, easy_auth
from app.validators.patient import validator_patient, validator_edit_patient
from app.model.model import Patient, Address, Special_Cares

router = APIRouter()


@router.post("/patient", status_code=201)
def add_patient(patient: PatientIn, token: str = Depends(get_current_user)):
    patient = validator_patient(patient)
    patient = patient.dict()
    print(patient)

    address = patient["address"]
    address = Address(**address)
    del patient["address"]
    patient = Patient(**patient)
    try:
        db.session.add(address)
        db.session.flush()
        patient.fk_address = address.id
        db.session.add(patient)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
    return "Created"


@router.get("/patients", status_code=200)
def get_all(token: str = Depends(get_current_user)):
    patients = db.session.query(Patient).all()
    patients = PatientList.from_orm(patients)

    return patients


@router.put("/patient/{id}", status_code=200)
def edt_patient(id: str, patient: PatientEdit, token: str = Depends(get_current_user)):
    patient = validator_edit_patient(patient)
    patient = patient.dict()
    db_pacient = db.session.query(Patient).filter_by(public_id=id).first()
    if not db_pacient:
        raise HTTPException(404, "Paciente não encontrado")

    address = patient["address"]
    del patient["address"]

    special_cares = patient["special_cares"]
    del patient["special_cares"]

    db.session.query(Patient).filter_by(public_id=db_pacient.public_id).update(
        patient, synchronize_session=False
    )
    db.session.flush()

    if db_pacient.fk_address is None:
        address = Address(**address)
        db.session.add(address)
        db.session.flush()
        db_pacient.fk_address = address.id
        db.session.commit()
    else:
        db.session.query(Address).filter_by(id=db_pacient.fk_address).update(
            address, synchronize_session=False
        )

    if special_cares is not None:
        if db_pacient.fk_special_cares is None:
            special_cares = Special_Cares(**special_cares)
            db.session.add(special_cares)
            db.session.flush()
            db_pacient.fk_special_cares = special_cares.id
            db.session.commit()
        else:
            db.session.query(Special_Cares).filter_by(
                id=db_pacient.fk_special_cares
            ).update(special_cares, synchronize_session=False)

    db.session.commit()


@router.delete("/patient/{id}", status_code=200)
def del_patient(id: str, token: str = Depends(get_current_user)):
    db.session.query(Patient).filter_by(id=id).delete()
    db.session.commit()


@router.get("/patient/{id}", status_code=200)
def get_one(id: str, token: str = Depends(get_current_user)):
    patient = db.session.query(Patient).filter_by(public_id=id).first()
    patient = PatientAll.from_orm(patient)
    return patient

@router.get("/patient_edt/{id}", status_code=200)
def get_edt(id: str, token: str = Depends(get_current_user)):
    patient = db.session.query(Patient).filter_by(public_id=id).first()
    patient = PatientAll.from_orm(patient)
    return patient


@router.get("/patient_basic/{id}", status_code=200)
def get_one(id: str, token: str = Depends(get_current_user)):
    patient = db.session.query(Patient).filter_by(public_id=id).first()
    patient = BasePatient.from_orm(patient)
    return patient
