from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash

db = SQLAlchemy()



class Credentials(db.Model):
    __tablename__ = 'credentials'
    id_user= db.Column(db.Integer, primary_key = True)
    email = db.Column(db.String(70), unique = True, nullable = False)
    password = db.Column(db.String(150), nullable = False)
    name = db.Column(db.String(120), nullable = False)
    admin = db.Column(db.Integer, nullable = False)
    token = db.Column(db.String(120), nullable = True)

    def __init__(self, email, password, name, admin, token):
        self.email = email
        self.password = generate_password_hash(password, method='sha256')
        self.name = name
        self.admin = admin
        self.token = token
    
    def __repr__(self):
        return  "%r" % self.email