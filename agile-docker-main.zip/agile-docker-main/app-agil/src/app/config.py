import os
basedir = os.path.abspath(os.path.dirname(__file__))
BASEURL = os.getenv('BASE_URI','https://api.julianaparreira.com')
FRONTURL = os.getenv('FRONTEND','https://app.julianaparreira.com')
class Config(object):
    DEBUG = True
    DEVELOPMENT = True
    SQLALCHEMY_DATABASE_URI ='sqlite:///' + os.path.join(basedir, 'app.db')
    SECRET_KEY = '$#!$GYSDFDSHGSD'
    FLASK_SECRET = SECRET_KEY