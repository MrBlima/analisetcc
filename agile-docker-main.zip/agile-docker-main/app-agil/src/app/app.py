from flask import Flask
from flask_cors import CORS
from model.model import db
from login import login_bp
from routes import routes_bp
def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')


    db.init_app(app)
    db.app = app

    app.register_blueprint(login_bp)
    app.register_blueprint(routes_bp)


    return app 