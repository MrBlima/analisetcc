from flask import url_for, session, flash, Markup, redirect, render_template
from model.model import db, Credentials
import functools


def login_required(func):
    @functools.wraps(func)
    def secure_function(*args, **kwargs):
        if 'user_on' not in session or session['user_on'] == None:
            message = Markup("<p style='color:red;'>Faça Login primeiro</p>")
            flash(message)
            return redirect(url_for('routes.login_page'))
        return func(*args, **kwargs)

    return secure_function


def admin_required(func):
    @functools.wraps(func)
    def secure_function(*args, **kwargs):
        query = Credentials.query.get(session['user_on'])
        if query.admin == 0:
            return render_template('forbidden.html')
        return func(*args, **kwargs)
    return secure_function


def get_name():
    query = Credentials.query.get(session['user_on'])
    if query is not None:
        return query.name.split()[0]
    else:
        return ''

def get_token():
    query = Credentials.query.get(session['user_on'])
    return query.token