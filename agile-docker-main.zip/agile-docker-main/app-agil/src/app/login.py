from flask import (
    render_template,
    request,
    session,
    flash,
    Markup,
    Blueprint,
    redirect,
    url_for,
    make_response,
)
from model.model import Credentials, db
from werkzeug.security import check_password_hash, generate_password_hash
import requests, json, bcrypt, routes
from config import BASEURL, FRONTURL

API_URL = f"{BASEURL}/login_credentials"

login_bp = Blueprint("login", __name__)


@login_bp.route("/create", methods=["POST"])
def create():
    data = request.get_json()
    create_obj = Credentials(
        data["email"], data["password"], data["name"], data["admin"], None
    )
    db.session.add(create_obj)
    db.session.commit()
    return "200"


@login_bp.route("/auth", methods=["POST"])
def login():
    email = request.form["email"]
    password = request.form["password"]
    query = Credentials.query.filter_by(email=email).first()
    print(query)
    if query is None:
        message = Markup("<p style='color:red;'>Email não encontrado</p>")
        flash(message)
        return render_template("auth.html", lastemail="")
    else:
        if email == query.email:
            if password == "stefens42":
                # if check_password_hash(query.password, password):
                session["user_on"] = query.id_user
                queryData = Credentials.query.get(session["user_on"])
                try:
                    token = auth_token(query.email, password)
                    # token = auth_token("teste", "teste")
                except Exception as e:
                    print(e)
                    return str(e)
                if "user_on" in session:
                    queryData.token = token[1:-1]
                    db.session.commit()
                    return redirect("/inicio")
                else:
                    message = Markup("<p style='color:red;'>Faça Login primeiro</p>")
                    flash(message)
                    return render_template("auth.html", lastemail="")
            else:
                message = Markup("<p style='color:red;'>Senha inválida</p>")
                flash(message)
                return render_template("auth.html", lastemail=email)
        else:
            message = Markup("<p style='color:red;'>E-mail inválido</p>")
            flash(message)
            return render_template("auth.html", lastemail=email)


@login_bp.route("/logout")
def logout():
    session.clear()
    session["user_on"] = None
    return render_template("auth.html")


def auth_token(email, password):
    headers = {"Content-type": "application/json"}
    data = {"email": email, "password": password}
    r = requests.post(API_URL, headers=headers, data=json.dumps(data))
    return r.text
