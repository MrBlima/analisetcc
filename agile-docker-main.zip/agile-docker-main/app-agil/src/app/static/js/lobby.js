var cache = [];
getLobby()
setInterval(function(){getLobby(); }, 3000);



function renderRows(data) {
    console.log(data);
    cache = data;
    let count = [];
    count[0] = data.filter((obj) => obj.insurance === 'FUSEX').length;
    count[1] = data.filter((obj) => obj.insurance === 'UNIMED').length;
    count[2] = data.filter((obj) => obj.insurance === 'PARTICULAR').length;
    getChart(count)

    console.log(count[0])

    for (var i = 0; i < data.length; i++){
        console.log(i);
        var $tr = $("<tr>");
        var $name = $('<td class="pt-3-half text-center" >');
        var $age = $('<td class="pt-3-half text-center" >');
        var $insurance = $('<td class="pt-3-half text-center">');
        var $atendimento = $('<td class="pt-3-half text-center">');
        var $lastvisit = $('<td class="pt-3-half text-center">');
        var $consult = $(`<td class="pt-3-half text-center">`);
        
       

        $name.append(data[i].name);
        $age.append(data[i].age);
        $insurance.append(data[i].insurance);      
        $atendimento.append(data[i].scheduling_type); 
        $lastvisit.append(data[i].last_visit);
        $consult.append($(`<a href='/atendimento/${data[i].public_id}' class="btn btn-primary">Iniciar</a>`))
        
        
        $tr.append($name);
        $tr.append($age);
        $tr.append($insurance);      
        $tr.append($atendimento);
        $tr.append($lastvisit);
        $tr.append($consult);
        
        $('#table').append($tr);
    }

}



function getLobby(){
    var chart = [];
    
    axios.get(`${baseURL}/lobby`)
        .then(function(response){
            
            data = response.data;

            if (cache == '')
                renderRows(data);
            else{
                if (JSON.stringify(cache) != JSON.stringify(data)){
                    $('#table > tr').remove();
                    renderRows(data);
                    
                    
                }
            }
        })
        .catch(function(error){

        })
}

function getChart(dataInsurance){
    Chart.defaults.global.legend.position = 'bottom';

    let dados = {
        datasets: [{
            data: dataInsurance,
            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc']
        }],
        labels: ['FUSEX', 'UNIMED', 'PARTICULAR']
    };
    let opcoes = {
        cutoutPercentage: 40,
        maintainAspectRatio: false
    };
    var ctx = document.getElementById("myChart").getContext('2d');

            let meuDonutChart = new Chart(ctx, {
        type: 'doughnut',
        data: dados,
        options: opcoes
    })
}