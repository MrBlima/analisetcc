$(document).ready(function () {
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    today = dd + '-' + mm + '-' + yyyy;

    requestSchList(today)
    $('#dateCalendar').val(today);
    $('#phone').mask('(00)00000-0000');

});

let currentHour;
function getDay(el) {
    var _day = el.textContent
    var selected = document.getElementsByClassName("select")[0];
    if (selected)
        selected.className = 'cld-day currMonth'
    el.className += ' select'
    var _mounth = document.getElementById("ano").textContent;
    _yearmouth = _mounth.split(",");
    _mounth = 1 + months.indexOf(_yearmouth[0]);
    if (String(_mounth).length == 1) {
        _mounth = '0' + _mounth;
    }
    if (String(_day).length == 1) {
        _day = '0' + _day;
    }
    _year = _yearmouth[1];

    $('#dateCalendar').val(`${_day}-${_mounth}-${_year.substring(1)}`);
    console.log($('#dateCalendar').val());
    requestSchList(`${_day}-${_mounth}-${_year}`);
}
var dir = window.location.href;
dir = dir.split("/")[4];
axios.defaults.headers.common['Authorization'] = document.querySelector('#token').value;

function requestSchList(day) {
    day = day.replace(/\s/g, '')
    axios.get(`${baseURL}/scheduling/${day}`)
        .then(function (response) {
            console.log(response.data)
            res = response.data
            if (res == 'No patients') {
                $('.table td').remove()
            }
            else {
                $('.table td').remove()
                for (let j = 0; j < res.length; j++) {
                    console.log(res[j]);
                    renderRows(res[j]);
                }
            }
        })
        .catch(function (error) {

        })
}

function buttonConf(btn, btnInfo, btnId) {

    if (btn) {
        return `<span name="${btnInfo}" id="${btnId}" onclick="changeState(this)" style="color: green" class="fa fa-check-circle fa-lg" aria-hidden="true"></span>`
    }
    else {
        return `<span name="${btnInfo}" id="${btnId}" onclick="changeState(this)" class="fa fa-check-circle fa-lg" aria-hidden="true"></span>`
    }
}

function changeState(el) {
    let data;
    if (!el.hasAttribute("style")) {
        el.setAttribute("style", "color:green");
        console.log(el.getAttribute("name"));
        data = { id: parseInt(el.id), [el.getAttribute("name")]: true }
    }
    else {
        el.removeAttribute("style");
        console.log("desativou")
        data = { id: parseInt(el.id), [el.getAttribute("name")]: false }
    }
    editState(data)
}

function renderRows(data) {
    data.hour = data.hour.replace(/:/g, '')
    $(`.table tr#${data.hour}`).each(function (key, el) {
        console.log(data.hour)
        // For example add five TDs to your table
        $(this).append(`<td onclick="deleteBox(${data.id})" style="width:11vw;">${data.name}</td>`);
        $(this).append(`<td style="width:15vw;">${data.phone}</td>`);
        $(this).append(`<td>${data.insurance}</td>`);
        $(this).append(`<td>${data.scheduling_type}</td>`);
        $(this).append(`<td>${data.last_visit}</td>`);
        $(this).append(`<td class="text-center">${buttonConf(data.is_confirmed, 'is_confirmed', data.id)}</td>`);
        $(this).append(`<td class="text-center">${buttonConf(data.is_present, 'is_present', data.id)}</td>`);
    });
}

function insertRows(el) {
    if ($(`#${el.id}`).find('td').length > 0) {

    }
    else {
        let hour = $(`#${el.id}`).find('th')[0].innerText;
        currentHour = hour;
        addSchedule(hour)
    }
}



function addSchedule(hour) {
    let showDate = document.querySelector("#dateCalendar").value;
    showDate = showDate.replace(/-/g,'/');
    document.querySelector('#dateShow').textContent = `Data: ${showDate}`;
    $('#main-modal').modal('show');
}


getPeople();

function getPeople() {
    axios.get(`${baseURL}/patients_name`)
        .then(function (res) {
            $(function () {
                $("#name").autocomplete({
                    source: res.data
                });
            });
        });    
}



elDivCustomConv = document.querySelector('#divCustomConv');

document.querySelector('#insurance').addEventListener('change', (e) => {
    if (e.target.value == '0') {
        elDivCustomConv.removeAttribute('style');
    }
    else {
        elDivCustomConv.setAttribute('style', 'display:none;');
    }
})


document.querySelector('#sendSch').addEventListener('click',(e)=>{
    e.preventDefault();
    if (!document.querySelector('#main-form').checkValidity())
        alert('Preencha todos os campos')
    data = {name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    insurance: document.getElementById('insurance').value,
    custom_insurance: document.getElementById('custom_insurance').value,
    fk_scheduling_type: document.getElementById('schedule_type').value,
    date_hour: `${$('#dateCalendar').val()} ${currentHour}`,
    is_confirmed: false,
    is_present: false
    }
    requestSchPatient(data);
    
})

function requestSchPatient(data) {
    const config = {
        headers: {
            'Content-Type': 'application/json',
        }
    }
    axios.post(`${baseURL}/scheduling`, data, config)
        .then(function (response) {
            Swal.fire(
                'Sucesso!',
                'Paciente cadastrado!',
                'success'
            )
            $('#main-modal').modal('hide');
            cleanSch();
            requestSchList($('#dateCalendar').val())
            
        })
        .catch(function (error) {
            Swal.fire(
                'Opa!',
                'Verifique se todos os campos foram preenchidos',
                'error'
            )
        })
}

function editState(data) {
    const config = {
        headers: {
            'Content-Type': 'application/json',
        }
    }
    axios.put(`${baseURL}/scheduling`, data, config)
}

function deleteBox(id_sch) {
    Swal.fire({
        title: 'Apagar agendamento?',
        text: "Você não pode reverter isso",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sim, apagar!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            axios.delete(`${baseURL}/scheduling/${id_sch}`)
                .then(function (response) {
                    Swal.fire(
                        'Apagado!',
                        'O agendamento foi removido',
                        'success'
                    )
                    requestSchList($('#dateCalendar').val());
                })

        }
    })
    //axios.delete(`http://0.0.0.0:5000/scheduling/${id_sch}`)
}


function cleanSch(){
    $('#name').val('');
    $('#phone').val('');
    $('#insurance').val('PARTICULAR');
    $('#schedule_type').val('1');
}