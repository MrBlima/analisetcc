const pStrings = {
    phone: 'CONTATO 1: ',
    cellphone: 'CONTATO 2: ',
    allergic_substances: 'ALERGIAS: ',
    drugs: 'MEDICAMENTOS: ',
    observations: 'OBSERVAÇÕES: ',
    ortese: 'ÓRTESE: '



}


var dir = window.location.href;
dir = dir.split("/")[4];
axios.defaults.headers.common['Authorization'] = document.querySelector('#token').value;


axios.get(`${baseURL}/patient/${dir}`)
    .then(function(response){
        console.log(response.data);
        renderInfo(response.data)
        render();
    })
    .catch(function(error){
        
    })


function renderInfo(data){
    $('#namePat').text = "Aaa";
    $('#edit').attr("href", '/cadastro_completo/'+ dir);
    $('#consultBtn').attr("href", '/atendimento/'+ dir);

}


function render(){
    axios.get(`${baseURL}/patient/${dir}`)
        .then(function(response){
            console.log(response.data);
            var data = JSON.stringify(response.data).replace(/null/g, '""');  //Remove null e converte para string
            data = JSON.parse(data); 
            console.log(data)
            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                  $('.basic[name=' + key + ']').text(data[key]);
                  $('.complete[name=' + key + ']').text(pStrings[key]+data[key]);
                }
            }
            if (data.hasOwnProperty('address')){  
                if (data.address != " "){
                let addr = `${data.address['street']}, ${data.address['neighborhood']}, ${data.address['number']}`
                $('.addr[name=address]').text(`ENDEREÇO: ${addr}`);
            }
            else{
                $('.addr[name=address]').text(`ENDEREÇO: `);
            }

                
            }
            if (data.hasOwnProperty('special_cares')){
                for(key in data.special_cares){
                    $('.cares[name=' + key + ']').text(pStrings[key]+data.special_cares[key]);
                }
                
            }
    
        })
        .catch(function(error){
            
        })
    }