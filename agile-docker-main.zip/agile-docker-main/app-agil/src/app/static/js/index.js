
$(document).ready(function() {
    navigator.geolocation.getCurrentPosition(success, error);
  
    function success(pos) {
      var lat = pos.coords.latitude;
      var long = pos.coords.longitude;
      weather(lat, long);
    }
  
    function error() {
      console.log("There was an error");
    }
  
    function weather(lat, long) {
     var URL = `https://fcc-weather-api.glitch.me/api/current?lat=${lat}&lon=${long}`;
      axios.get(URL)
      .then(function(response){
        display(response.data);
      })
      .catch(function(error){
        console.log(error)
      })
    }
  
    function display(data) {
      var city = data.name.toUpperCase();
      var temp =
        Math.round(data.main.temp_max) +
        "&deg; C  ";
      var date = new Date();
  
      var months = [
        "Janeiro",
        "Feveiro",
        "Março",
        "Abril",
        "Maio",
        "Junho",
        "Julho",
        "Agosto",
        "Setembro",
        "Outubro",
        "Novembro",
        "Dezembro"
      ];
  
      var weekday = new Array(7);
      weekday[0] = "Segunda";
      weekday[1] = "Terça";
      weekday[2] = "Quarta";
      weekday[3] = "Quinta";
      weekday[4] = "Sexta";
      weekday[5] = "Sábado";
      weekday[6] = "Domingo";
  
  
  
      if (data.weather[0].main == "Sunny" || data.weather[0].main == "sunny") {
        $(".weathercon").html(
          "<i class='fa fa-sun' style='color: #d36326;'></i>"
        );
      } else {
        $(".weathercon").html(
          "<i class='fa fa-cloud' style='color: #44c3de;'></i>"
        );
      }
  
      var minutes =
        date.getMinutes() < 11 ? "0" + date.getMinutes() : date.getMinutes();
      var date =
        weekday[date.getDay()].toUpperCase() +
        " | " +
        months[date.getMonth()].toUpperCase().substring(0, 3) +
        " " +
        date.getDate() +
        " | " +
        date.getHours() +
        ":" +
        minutes;
      $(".location").html(city);
      $(".temp").html(temp);
      $(".date").html(date);
      $(".box").css("background", bg_color);
      $(".location").css("color", "#44c3de");
      $(".temp").css("color", "#eff3f9");
    }
  });
  