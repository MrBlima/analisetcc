function config(){
    return 'a'
}

export default config;
