$(document).ready(function () {
  getUser();
  $("#summernote").summernote({
    height: 600,
    callbacks: {
      onKeyup: function (e) {
        handleKeyUp("text-save-Anam");
      },
      onKeydown: function () {
        handleKeyPress("text-save-Anam");
      },
    },
  });
  // $('#summernote2').summernote({
  //   height: 400
  // });
  // $('#summernote3').summernote({
  //   height: 400
  // });
  $("#carousel-id").carousel({
    interval: false,
  });
  $("#carousel-id2").carousel({
    interval: false,
  });
});

var dir = window.location.href;
dir = dir.split("/")[4];
let status = document.getElementById("text-save-Anam");
let timer, timeoutVal = 1000;
axios.defaults.headers.common["Authorization"] =
  document.querySelector("#token").value;

$('input[name="check-min"]').change(function () {
  console.log(document.querySelectorAll("input:checked").length - 2);
  var el = document.getElementById("result_minemental");
  el.textContent = `Resultado: ${document.querySelectorAll("input:checked").length - 2
    }`;
});

$('input[name="number-clock"]').change(function () {
  var sum = 0;
  $('input[name="number-clock"]').each(function () {
    sum += +$(this).val();
  });
  document.getElementById(
    "result_clock_test"
  ).textContent = `Resultado: ${sum}`;
});

$('input[name="number-moca"]').change(function () {
  var sum = 0;
  $('input[name="number-moca"]').each(function () {
    sum += +$(this).val();
  });
  document.getElementById("result_moca").textContent = `Resultado: ${sum}`;
});

let outTime = false;

function initTimer() {
  document.getElementById("sidebarCollapse").click();
  startTimer();
}

function startTimer() {
  var box = document.getElementById("boxTimer");
  var presentTime = document.getElementById("pTimer").innerHTML;

  var timeArray = presentTime.split(/[:]+/);
  var m = timeArray[0];
  var s = checkSecond(timeArray[1] - 1);
  if (s == 59) {
    m = m - 1;
  }
  if (m < 0) {
    outTime = true;
    m = 0;
    s = "00";
  }
  if (m < 10) {
    box.setAttribute("style", "background-color:rgb(219, 176, 5) !important");
  }
  if (m < 5) {
    box.setAttribute("style", "background-color:rgb(240, 62, 30); !important");
  }

  document.getElementById("pTimer").innerHTML = m + ":" + s;
  if (!outTime) {
    setTimeout(startTimer, 1000);
  }
}

function checkSecond(sec) {
  if (sec < 10 && sec >= 0) {
    sec = "0" + sec;
  } // add zero in front of numbers < 10
  if (sec < 0) {
    sec = "59";
  }
  return sec;
}

function getResult(test) {
  return parseInt(
    document.getElementById(`result${test}`).textContent.split(" ")[1]
  );
}

function saveRequest(btn) {
  btn = btn.id.split("btn")[1];
  console.log(btn);
  let data;
  if (btn == "anamnese") {
    data = escape($("#summernote").summernote("code"));
    data = { id_patient: dir, anamnese: data };
  } else {
    data = parseInt(
      document.getElementById(`result_${btn}`).textContent.split(" ")[1]
    );
    data = { id_patient: dir, [btn]: data };
  }
  console.log(data);
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  axios
    .post(`${baseURL}/anamnese`, data, config)
    .then(function (response) {
      Swal.fire("Sucesso!", "Anamnese salva!", "success");
    })
    .catch(function (error) {
      console.log(error.message);
      btnSave.disabled = false;
      Swal.fire("Opa!", String(error.message), "error");
    });
}

function getUser() {
  axios.get(`${baseURL}/patient_basic/${dir}`).then(function (response) {
    res = response.data;
    $("#name").text(res.name);
    $("#birthday").text(res.birthday);
    $("#summernote").summernote("code", unescape(res.anamnese.anamnese));
    document.querySelector(
      "#profile-image"
    ).src = `${baseURL}/photo/${res.photo}`;
  });
}

function Finish() {
  axios
    .put(`${baseURL}/finish_anam/${dir}`)
    .then(function (response) {
      Swal.fire({
        title: "Sucesso!",
        text: "Consulta finalizada!",
        icon: "success",
      }).then(function (result) {
        if (result.value) window.location = "/lobby";
      });
    })
    .catch(function (error) {
      Swal.fire("Opa!", String(error.data.detail), "error");
    });
}

// time it takes to wait for user to stop typing in ms

// pointers to our simple DOM elements

function handleKeyUp(el) {
  window.clearTimeout(timer); // prevent errant multiple timeouts from being generated
  timer = window.setTimeout(() => {
    status.innerHTML = "Salvando...";
    data = escape($("#summernote").summernote("code"));
    data = { id_patient: dir, anamnese: data };
    saveData(data);
  }, timeoutVal);
}

async function saveData(data) {
  await axios
    .post(`${baseURL}/anamnese`, data)
    .then(function (response) {
      status.innerHTML = "Salvo!";
    })
    .catch(function (error) {
      status.innerHTML = "Erro";
    });
}

function handleKeyPress(el) {
  window.clearTimeout(timer);
  status.innerHTML = "Digitando...";
}

async function AtachInfo(msg, el) {
  let text = `<p>${msg}:</p>${$("#summernote" + el).summernote("code")}`;
  $("#summernote").summernote(
    "code",
    $("#summernote").summernote("code") + text
  );
  data = {
    id_patient: dir,
    anamnese: escape($("#summernote").summernote("code")),
  };
  try {
    await saveData(data);
    Swal.fire("Sucesso!", "Anamnese salva!", "success");
  } catch (e) {
    Swal.fire("Opa!", "Erro inesperado!", "error");
  }
}
