$(document).ready(function() {

    
    navigator.geolocation.getCurrentPosition(getWeather);
    getAnnotation();
});
axios.defaults.headers.common['Authorization'] = document.querySelector('#token').value;
function getWeather(position) {
    let lat = position.coords.latitude;
    let long = position.coords.longitude;
    let Baseurl = `https://fcc-weather-api.glitch.me/api/current?lat=${lat}&lon=${long}`
    axios.get(Baseurl)
        .then(function (response) {
            display(response.data);
        })
        .catch(function (error) {
            console.log(error)
        })
}

var months = [
    "Janeiro",
    "Feveiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro"
];

var weekday = new Array(7);
weekday[0] = "Segunda";
weekday[1] = "Terça";
weekday[2] = "Quarta";
weekday[3] = "Quinta";
weekday[4] = "Sexta";
weekday[5] = "Sábado";
weekday[6] = "Domingo";



function getTime(){
    var date = new Date();
    let minutes =
    date.getMinutes() < 11 ? "0" + date.getMinutes() : date.getMinutes();
    date =
    weekday[date.getDay()].toUpperCase() +
    " | " +
    months[date.getMonth()].toUpperCase().substring(0, 3) +
    " " +
    date.getDate() +
    " | " +
    date.getHours() +
    ":" +
    minutes;
    return date;
}

function display(data) {
    


    if (data.weather[0].main == "Sunny" || data.weather[0].main == "sunny") {
        $(".weathercon").html(
            "<i class='fa fa-sun' style='color: #d36326;'></i>"
        );
    } else {
        $(".weathercon").html(
            "<i class='fa fa-cloud' style='color: #44c3de;'></i>"
        );
    }

    $(".location").html(data.name.toUpperCase());
    $(".temp").html(Math.round(data.main.temp_max) +
    "&deg; C  ");
    $(".date").html(getTime());
    
    $(".box").css("background", "#eff3f9");
    $(".location").css("color", "#44c3de");
    $(".temp").css("color", "#44c3de");
}

setInterval(() => {
    $(".date").html(getTime());
    getAnnotation();
},60000 );





let timer,
    timeoutVal = 1000; // time it takes to wait for user to stop typing in ms

// pointers to our simple DOM elements
const status = document.getElementById('text-save');
const typer = document.getElementById('annotation');
typer.addEventListener('keypress', handleKeyPress);
// triggers a check to see if the user is actually done typing
typer.addEventListener('keyup', handleKeyUp);

function handleKeyUp(e) {
    window.clearTimeout(timer); // prevent errant multiple timeouts from being generated
    timer = window.setTimeout(() => {
    status.innerHTML = 'Salvando...';
    el_anot = document.querySelector("#annotation");
    var obj = `{
        "annotation" : "${el_anot.value}"
        }`;

    axios.post('http://0.0.0.0:5000/annotation', JSON.parse(obj))
    .then(function(response){
        status.innerHTML = 'Salvo!'
    })
    .catch(function(error){
        status.innerHTML= 'Erro';
    })
    }, timeoutVal);
  }

  function handleKeyPress(e) {
    window.clearTimeout(timer);
    status.innerHTML = 'Digitando...';
  }


function getAnnotation(){
    status.innerHTML = 'Atualizando...';
    axios.get('http://0.0.0.0:5000/annotation')
    .then(function(response){
        el_anot = document.querySelector("#annotation");
        el_anot.value = response.data;
        status.innerHTML = '';
    })
    .catch(function(error){

    })

}