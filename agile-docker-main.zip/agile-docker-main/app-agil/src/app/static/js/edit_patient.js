$(document).ready(function(){
    $('#cpf').mask('000.000.000-00', {reverse: true}); 
    $('#phone').mask('(00)00000-0000');
    $('#phone2').mask('(00)00000-0000');
});

const DOMstrings = {
    stepsBtnClass: 'multisteps-form__progress-btn',
    stepsBtns: document.querySelectorAll(`.multisteps-form__progress-btn`),
    stepsBar: document.querySelector('.multisteps-form__progress'),
    stepsForm: document.querySelector('.multisteps-form__form'),
    stepsFormTextareas: document.querySelectorAll('.multisteps-form__textarea'),
    stepFormPanelClass: 'multisteps-form__panel',
    stepFormPanels: document.querySelectorAll('.multisteps-form__panel'),
    stepPrevBtnClass: 'js-btn-prev',
    stepNextBtnClass: 'js-btn-next',
    finishBtn: 'btn-success'
};


//remove class from a set of items
const removeClasses = (elemSet, className) => {

    elemSet.forEach(elem => {

        elem.classList.remove(className);

    });

};

//return exect parent node of the element
const findParent = (elem, parentClass) => {

    let currentNode = elem;

    while (!currentNode.classList.contains(parentClass)) {
        currentNode = currentNode.parentNode;
    }

    return currentNode;

};

//get active button step number
const getActiveStep = elem => {
    return Array.from(DOMstrings.stepsBtns).indexOf(elem);
};

//set all steps before clicked (and clicked too) to active
const setActiveStep = activeStepNum => {

    //remove active state from all the state
    removeClasses(DOMstrings.stepsBtns, 'js-active');

    //set picked items to active
    DOMstrings.stepsBtns.forEach((elem, index) => {

        if (index <= activeStepNum) {
            elem.classList.add('js-active');
        }

    });
};
axios.defaults.headers.common['Authorization'] = document.querySelector('#token').value;
//get active panel
const getActivePanel = () => {

    let activePanel;

    DOMstrings.stepFormPanels.forEach(elem => {

        if (elem.classList.contains('js-active')) {

            activePanel = elem;

        }

    });

    return activePanel;

};

//open active panel (and close unactive panels)
const setActivePanel = activePanelNum => {

    //remove active class from all the panels
    removeClasses(DOMstrings.stepFormPanels, 'js-active');

    //show active panel
    DOMstrings.stepFormPanels.forEach((elem, index) => {
        if (index === activePanelNum) {

            elem.classList.add('js-active');

            setFormHeight(elem);

        }
    });

};

//set form height equal to current panel height
const formHeight = activePanel => {

    const activePanelHeight = activePanel.offsetHeight;

    DOMstrings.stepsForm.style.height = `${activePanelHeight}px`;

};

const setFormHeight = () => {
    const activePanel = getActivePanel();

    formHeight(activePanel);
};

//STEPS BAR CLICK FUNCTION
DOMstrings.stepsBar.addEventListener('click', e => {

    //check if click target is a step button
    const eventTarget = e.target;

    if (!eventTarget.classList.contains(`${DOMstrings.stepsBtnClass}`)) {
        return 'bb';
    }

    //get active button step number
    const activeStep = getActiveStep(eventTarget);

    //set all steps before clicked (and clicked too) to active
    setActiveStep(activeStep);

    //open active panel
    setActivePanel(activeStep);
});

//PREV/NEXT BTNS CLICK
DOMstrings.stepsForm.addEventListener('click', e => {

    const eventTarget = e.target;
    const finish = e;

    //check if we clicked on `PREV` or NEXT` buttons
    if (!(eventTarget.classList.contains(`${DOMstrings.stepPrevBtnClass}`) || eventTarget.classList.contains(`${DOMstrings.stepNextBtnClass}`))) {
        if (eventTarget.classList.contains(`${DOMstrings.finishBtn}`)) {
            submitHandler(e);

        }
        return;
    }

    //find active panel
    const activePanel = findParent(eventTarget, `${DOMstrings.stepFormPanelClass}`);

    let activePanelNum = Array.from(DOMstrings.stepFormPanels).indexOf(activePanel);

    //set active step and active panel onclick
    if (eventTarget.classList.contains(`${DOMstrings.stepPrevBtnClass}`)) {
        activePanelNum--;

    } else {

        activePanelNum++;

    }

    setActiveStep(activePanelNum);
    setActivePanel(activePanelNum);

});

//SETTING PROPER FORM HEIGHT ONLOAD
window.addEventListener('load', setFormHeight, false);

//SETTING PROPER FORM HEIGHT ONRESIZE
window.addEventListener('resize', setFormHeight, false);

//changing animation via animation select !!!YOU DON'T NEED THIS CODE (if you want to change animation type, just change form panels data-attr)

const setAnimationType = newType => {
    DOMstrings.stepFormPanels.forEach(elem => {
        elem.dataset.animation = newType;
    });
};

//selector onchange - changing animation
setAnimationType('slideHorz')



document.querySelector('#signupForm').addEventListener('submit', submitHandler);
var dir = window.location.href;
dir = dir.split("/")[4];
function submitHandler(e) {
    
    e.preventDefault();
    btnSave = document.querySelector('#save');
    btnSave.disabled = true;
    if (String(document.querySelector('#birthday').value).length != 10) {
        alert('Data de nascimento inválida');
    }
    if (document.forms["signupForm"].checkValidity()) {
        var data = $('#signupForm').find('.def').serializeArray()
            .reduce(function (a, x) {
                a[x.name] = x.value;
                console.log(x.name)
                if(x.name == 'gender'){
                    x.value = 'Gênero'
                }
                return a;
            },
                {});
        var data_addr = $('#signupForm').find('.addr').serializeArray()
            .reduce(function (a, x) {
                a[x.name] = x.value;
                return a;
            },
                {});
        var data_care= $('#signupForm').find('.cares').serializeArray()
            .reduce(function (a, x) {
                a[x.name] = x.value;
                return a;
            },
                {});

        const isEmpty = Object.values(data_care).every(x => (x === null || x === ''));

        Object.assign(data, { address: data_addr }, {special_cares: data_care});
        if(isEmpty)
            Object.assign(data, { address: data_addr });
        else
            Object.assign(data, { address: data_addr }, {special_cares: data_care});
        Object.assign(data, { photo: canvas.toDataURL("image/png").split(',')[1]});
        console.log(data)
        data = JSON.stringify(data);
        data = data.replace(/\\/g, '');


        const config = {
            headers: {
                'Content-Type': 'application/json',
            }
        }
        btnSave.disabled = true;
        axios.put(`${baseURL}/patient/${dir}`, data, config)
            .then(function (response) {
                Swal.fire({
                    title:'Sucesso!',
                    text:'Paciente cadastrado!',
                    icon:'success',
                    confirmButtonText: "OK"
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        window.location.href = `/paciente/${dir}`;
                    }})
            })
            .catch(function (error) {
                console.log(error.response.data.detail);
                Swal.fire(
                    'Opa!',
                    String(error.response.data.detail),
                    'error'
                )
            })
        
    }
    else{
        Swal.fire(
            'Opa!',
            'Preencha todos os campos obrigatórios!',
            'error'
        )
        
    }


    btnSave.disabled = false;

}

$(document).ready(function () {
    masks();
    render();
});


function masks(){
    $('#cpf').mask('000.000.000-00', { reverse: true });
    $('.phone').mask('(00)00000-0000');
    $('#telephone').mask('(00)00000-0000');
}

function render(){
axios.get(`${baseURL}/patient_edt/${dir}`)
    .then(function(response){
        console.log(response.data);
        var data = JSON.stringify(response.data).replace(/null/g, '""');  //Remove null e converte para string
        data = JSON.parse(data); 
        console.log(data)
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
              $('[name=' + key + ']').val(data[key]);
            }
        }
        if (data.hasOwnProperty('address')){
            for(key in data.address){
                console.log(data.address[key])
                $('[name=' + key + ']').val(data.address[key]);
            }
            
        }
        if (data.hasOwnProperty('special_cares')){
            for(key in data.special_cares){
                console.log(data.special_cares[key])
                $('[name=' + key + ']').val(data.special_cares[key]);
            }
            
        }

    })
    .catch(function(error){
        
    })
}

function reziseTable(){
    $('#content').attr('style',"margin-left: 5vw")
}

var open = true;