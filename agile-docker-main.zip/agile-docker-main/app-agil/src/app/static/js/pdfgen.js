

function ab(){
    var name = document.getElementById('name').value;
    var listRq = [];
    var h = 70;
    var checkedValue = $('.form-check-input:checked');
    for (var i = 0; i < checkedValue.length; i++) {
        listRq.push('-'+ document.querySelector('label[for="' + checkedValue[i].id + '"]').innerText);
     }
     listRq.push(`- ${$('#horm').val()}`);
     listRq.push(`- ${$('#mark').val()}`);
     listRq.push(`- ${$('#other').val()}`);
    console.log(listRq);
    console.log(name);
    var doc = new jsPDF();
    doc.setFontSize(12);
    doc.text('Solicito para o Sr(a) ' + name + ' os seguintes exames:', 25, 60);
    for (var i = 0; i < listRq.length; i++) {
        doc.text(listRq[i], 30, h);
        h = h + 10;
    }
    doc.save('a4.pdf')
}