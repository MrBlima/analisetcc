document.querySelector('#signupForm').addEventListener('submit', submitHandler);
axios.defaults.headers.common['Authorization'] = document.querySelector('#token').value;

function submitHandler(e){
    e.preventDefault();
    btnSave = document.querySelector('#save');
    btnSave.disabled = true;
    if (String(document.querySelector('#inputBirthday').value).length != 10){
        alert('erro');
    }
    var data = $('#signupForm').find('.def').serializeArray()
    .reduce(function(a, x){
        a[x.name] = x.value;
        return a; 
        }, 
    {});
    var data_addr = $('#signupForm').find('.addr').serializeArray()
    .reduce(function(a, x){
        a[x.name] = x.value;
        return a; 
        }, 
    {});
    Object.assign(data, {address : data_addr});
    data = JSON.stringify(data);
    data = data.replace(/\\/g, '');
    console.log(data);
    
    const config = {
        headers:{
            'Content-Type': 'application/json',
        }
    }
    axios.post(`${baseURL}/patient`, data, config)
        .then(function(response){
            Swal.fire(
                'Sucesso!',
                'Paciente cadastrado!',
                'success'
              )
        })
        .catch(function(error){
            btnSave.disabled = false;
            Swal.fire(
                'Opa!',
                String(error.response.data.detail),
                'error'
              )
        })

}

$(document).ready(function(){
    $('#inputCpf').mask('000.000.000-00', {reverse: true}); 
    $('#inputPhone').mask('(00)00000-0000');
    $('#inputPhone2').mask('(00)00000-0000');
});



