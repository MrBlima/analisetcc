axios.defaults.headers.common['Authorization'] = document.querySelector('#token').value;
var data;
$(document).ready(function() {
    DataTableInit();
    getPatients();
} );

function getPatients(){
    axios.get(`${baseURL}/patients`)
        .then(function(response){
            console.log(response.data);
            populateTable(response.data);
        })
        .catch(function(error){
            console.log(error);
        })
}

function populateTable(data){
    const tablePatients = $('#table');
    for (var i = 0; i < data.length; i++) {
        if (data[i].address !=" ")
            data[i].address = data[i].address.neighborhood
        if(data[i].anamnese == null){
            data[i].anamnese = "Primeira vez" 
        }
        else{
            data[i].anamnese = data[i].anamnese.date_update
        }
        tablePatients.DataTable().row.add([
            '<a class="text-dark" href="/paciente/' +data[i].public_id+ '">' + data[i].name,
            data[i].phone,
            data[i].address,
            data[i].birthday,
            data[i].anamnese
        ]).draw();
     }
}



 


function DataTableInit(){
    $('#table').DataTable({
        "columns":[
            null,
            {"width": "120px"},
            {"width": "50px"},
            null,
            null

        ],
        "bRetrieve": true,
        "info": true,
        "oLanguage": {
            "sSearch": "Procurar"
        },
        "language": {
            "paginate": {
              "previous": "Anterior",
              "next": "Próxima"
            }
        },
        dom: '<"toolbar">frtip',
        fnInitComplete: function(){
           $('div.toolbar').html('<a href="/cadastro"> <i class="fa fa-plus-circle fa-2x" style=" vertical-align: middle;" aria-hidden="true"></i> Novo paciente</a>');
         }
    });
}



function createTable(jsonStringData){ 
    $("#table").find('tbody').empty();
    for (var i = 0; i < jsonStringData.length; i++){
        var $tr = $("<tr>");
        var $id = $('<td hidden class="pt-3-half text-center" >');
        var $name = $('<td class="pt-3-half text-center" >');
        var $phone = $('<td class="pt-3-half text-center" >');
        var $age = $('<td class="pt-3-half text-center" >');
        var $address = $('<td class="pt-3-half text-center">');
        var $lastVisit = $('<td class="pt-3-half text-center">');
        //var hrefAnam = 'start_anam/'

        $name.append(jsonStringData[i].name);
        $age.append(jsonStringData[i].birthday);
        $phone.append(jsonStringData[i].phone);
        $address.append(jsonStringData[i].address);      
        $lastVisit.append(jsonStringData[i].lastVisit);
        
        
        //$tr.append('<td hidden>' + jsonStringData[i].triagem_id+ '</td>');
        $tr.append($name);
        $tr.append($age);
        $tr.append($phone);
        $tr.append($address);      
        $tr.append($lastVisit);
        
        $('#table').append($tr);
        
        //$("#start").attr("href", "start_anam/" + jsonStringData[i].public_id);            
    }
}