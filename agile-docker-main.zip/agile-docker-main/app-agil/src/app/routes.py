from flask import Blueprint, render_template, url_for, redirect
from util import login_required, admin_required, get_name, get_token
from config import BASEURL

routes_bp = Blueprint("routes", __name__)


@routes_bp.route("/")
def login_page():
    return render_template("auth.html", base=BASEURL)


@routes_bp.route("/inicio")
@login_required
def dashboard():
    return render_template(
        "index.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/pacientes")
@login_required
def patients():
    return render_template(
        "patients.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/paciente/<id>")
@login_required
def patient(id):
    return render_template(
        "patient.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/cadastro_completo/<id>")
@login_required
def edit_patient(id):
    return render_template(
        "edit_patient.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/cadastro")
@login_required
def new_patients():
    return render_template(
        "signup.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/atendimento/<id>")
@login_required
@admin_required
def medical_appointment(id):
    return render_template(
        "medical_appointment.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/atestado")
@login_required
@admin_required
def attestation():
    return render_template("attestation.html", name=get_name())


@routes_bp.route("/exames")
@admin_required
@login_required
def request_health():
    return render_template("request_health.html", name=get_name())


@routes_bp.route("/exames_imagem")
@admin_required
@login_required
def request_image():
    return render_template("request_image.html", name=get_name())


@routes_bp.route("/lobby")
@admin_required
@login_required
def lobby():
    return render_template("lobby.html", name=get_name(), base=BASEURL)


@routes_bp.route("/agendamento")
@login_required
def schedule():
    return render_template(
        "schedule.html", name=get_name(), token=get_token(), base=BASEURL
    )


@routes_bp.route("/about")
@login_required
def about():
    return render_template("about.html", name=get_name())
