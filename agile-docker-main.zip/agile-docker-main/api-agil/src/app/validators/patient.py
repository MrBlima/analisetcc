from fastapi import HTTPException, Depends
from app.model.model import Patient
from app.schema.patient import PatientIn, PatientEdit
from pycpfcnpj import cpfcnpj
from fastapi_sqlalchemy import db

def validator_patient(patient):
    with db():
        if not cpfcnpj.validate(patient.cpf):
            raise HTTPException(422, detail="CPF inválido")
        check_exits = db.session.query(Patient).filter_by(cpf = patient.cpf).first()
        if check_exits:
            raise HTTPException(422, detail="CPF já cadastrado")
        check_exits = db.session.query(Patient).filter_by(rg = patient.rg).first()
        if check_exits: 
            raise HTTPException(422, detail="RG já cadastrado")
        patient.name = patient.name.upper()
        return patient

def validator_edit_patient(patient):
    with db():
        if not cpfcnpj.validate(patient.cpf):
            raise HTTPException(422, detail="CPF inválido")
        patient.name = patient.name.upper()
        return PatientEdit.from_orm(patient)



