from fastapi_sqlalchemy import db
from app.model.model import Patient
from datetime import datetime, date

def get_pacient(public_id):
    with db():
        db_query = db.session.query(Patient).filter_by(public_id = public_id).first()
        return db_query


def get_days(day):
    day = datetime.strptime(str(day), "%Y-%m-%d").strftime("%m/%d/%Y")
    #day = day.strftime("%Y-%m-%d")
    currentDate = datetime.now()
    deadlineDate= datetime.strptime(str(day),'%m/%d/%Y')
    daysLeft = currentDate - deadlineDate

    years = ((daysLeft.total_seconds())/(365.242*24*3600))
    yearsInt=int(years)

    months=(years-yearsInt)*12
    monthsInt=int(months)

    days=(months-monthsInt)*(365.242/12)
    daysInt=int(days)

    
    days = '{0:d} anos, {1:d}  meses e {2:d}  dias'.format(yearsInt,monthsInt,daysInt)
    return days
