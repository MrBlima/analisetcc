from pydantic import BaseModel, validator
from datetime import datetime
from datetime import date
from app.util import get_days
from typing import Optional

class LobbyOut(BaseModel):
    public_id: str
    name: str
    age: str
    insurance: str
    scheduling_type: str
    insurance: Optional[str]
    last_visit: str

    @validator('last_visit')
    def lastvis(cls, v):
        if v == '':
            return 'Primeira vez'
        else:
            v = datetime.strptime(v, "%Y-%m-%d").date()
            return v.strftime('%d/%m/%Y')

    @validator('age')
    def getbirth(cls, v):
        if v == 'None':
            v = "Não definido"
            return v
        return get_days(v)

    class Config:
        orm_mode = True