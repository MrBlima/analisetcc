from pydantic import BaseModel, validator
from typing import Optional
from datetime import date

class Anamnese(BaseModel):
    anamnese: Optional[str]
    clock_test: Optional[int]
    minemental: Optional[int]
    moca: Optional[int]
    date_update: Optional[date]

    class Config:
        orm_mode = True

    @validator('date_update')
    def dateToBr(cls, v):
        return v.strftime('%d/%m/%Y') if v else ''


class AnamneseIn(Anamnese):
    id_patient: str

    class Config:
        orm_mode = True

    @validator('id_patient')
    def removeS(cls, v):
        if '#' in v:
            return v.replace('#', '')
        else:
            return v