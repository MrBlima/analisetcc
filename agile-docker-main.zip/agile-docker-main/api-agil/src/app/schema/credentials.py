from pydantic import BaseModel

class CredentialsIn(BaseModel):
    email: str
    password: str

    class Config:
        orm_mode = True

class CredentialsOut(BaseModel):
    id: int
    email: str

    class Config:
        orm_mode = True
