from pydantic import BaseModel

class SpecialCaresOut(BaseModel):
    allergic : str
    drugs: str
    observations: str
    
    class Config:
        orm_mode= True

