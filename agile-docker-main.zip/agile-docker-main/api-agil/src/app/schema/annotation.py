from pydantic import BaseModel

class AnnotationIn(BaseModel):
    annotation: str

    class Config:
        orm_mode = True