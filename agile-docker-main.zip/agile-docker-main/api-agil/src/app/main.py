from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi_sqlalchemy import DBSessionMiddleware
from app.auth import auth
from app.resource.patient import patient
from app.resource.annotation import annotation
from app.resource.anamnese import anamnese
from app.resource.scheduling import scheduling
from app.resource.anamnese import lobby
from app.config import SQLALCHEMY_DATABASE_URL

app = FastAPI()

origins = ["https://app.julianaparreira.com", "https://app.julianaparreira.com/*", 'https://app.julianaparreira.com/\*', "*"]

app.add_middleware(DBSessionMiddleware, db_url=SQLALCHEMY_DATABASE_URL)
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods =["*"], allow_headers=["*"],)
app.include_router(auth.router)
app.include_router(patient.router)
app.include_router(annotation.router)
app.include_router(anamnese.router)
app.include_router(scheduling.router)
app.include_router(lobby.router)
