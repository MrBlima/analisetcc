from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import APIKeyHeader
from app.model.model import Credentials
from app.schema.credentials import CredentialsIn, CredentialsOut
from fastapi_sqlalchemy import db
import datetime, bcrypt, jwt
from app.config import JWT_SECRET
 


router = APIRouter()

salt = bcrypt.gensalt()

X_API_KEY = APIKeyHeader(name='X-API-Key')

@router.post('/credentials_create', status_code=201)
def credentials_create(credentials: CredentialsIn):
    hashed = bcrypt.hashpw(credentials.password.encode('utf-8'), salt).decode('utf-8')

    credentials_obj = Credentials(credentials.email,hashed)
    db.session.add(credentials_obj)
    db.session.commit()
    return "Created"



def authenticate_credentials(email: str, password: str):
    db_credentials = db.session.query(Credentials).filter_by(email = email).first()
    if not db_credentials:
        return False
    if not bcrypt.checkpw(password.encode('utf-8'), db_credentials.password.encode('utf-8')):
        return False
    return db_credentials

async def get_current_user(token: Request):
    try:
        token = token.headers['Authorization']
        print(token)
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        credentials = db.session.query(Credentials).filter_by(email = payload.get('email')).first()
    except:
        raise HTTPException(401, detail="Token error")

    credentials.id = str(credentials.id)
    return CredentialsOut.from_orm(credentials)


async def easy_auth(token : str = Depends(X_API_KEY)):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        credentials = db.session.query(Credentials).filter_by(email = payload.get('email')).first()
    except:
        raise HTTPException(401, detail="Token error")

    credentials.id = str(credentials.id)
    return CredentialsOut.from_orm(credentials)


@router.post('/login_credentials', status_code=200)
def credentials_login(credentials: CredentialsIn):
    credentials = authenticate_credentials(credentials.email, credentials.password)
    if not credentials:
        raise HTTPException(401, 'Invalid email or password')
    credentials.id = str(credentials.id)
    credentials_obj = CredentialsOut.from_orm(credentials).dict()
    credentials_obj['exp'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=21600)
    return jwt.encode(credentials_obj, JWT_SECRET)

@router.get('/protected', status_code=200)
def protected(token: str = Depends(easy_auth)):
    return token

    