from fastapi_sqlalchemy import db
from fastapi import APIRouter, Request, Depends

from app.auth.auth import easy_auth, get_current_user
from app.model.model import Annotation
from app.schema.annotation import AnnotationIn

router = APIRouter()


@router.post("/annotation", status_code=200)
def add_annotation(
    annotation: AnnotationIn, token: Request = Depends(get_current_user)
):
    db_text = db.session.query(Annotation).first()
    print(annotation.annotation)
    db_text.text = annotation.annotation
    db.session.commit()


@router.get("/annotation", status_code=200)
def get_annotation(token: Request = Depends(get_current_user)):
    text = db.session.query(Annotation).first()
    return str(text.text)
