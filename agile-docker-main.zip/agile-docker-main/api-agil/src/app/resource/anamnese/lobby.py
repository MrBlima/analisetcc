from fastapi_sqlalchemy import db
from fastapi import APIRouter, Request, Depends

from app.schema.lobby import LobbyOut
from app.model.model import Patient, Scheduling


router = APIRouter()

@router.get('/lobby', status_code=200)
def get_lobby():
    listPatients = []
    db_schedules = db.session.query(Scheduling).filter_by(is_present = True).all()
    
    for db_schedule in db_schedules:
        
        if not db_schedule.patient.anamnese:
            last_visit = ''
        else:
            last_visit = str(db_schedule.patient.anamnese.date_update)
        last_visit = last_visit
        lobbyPatient = LobbyOut (
        public_id = db_schedule.patient.public_id,
        name = db_schedule.patient.name,
        age = str(db_schedule.patient.birthday),
        phone = db_schedule.patient.phone,
        insurance =  db_schedule.custom_insurance if db_schedule.custom_insurance else db_schedule.insurance.name,
        scheduling_type = db_schedule.scheduling_type.name,
        last_visit = last_visit
    )
        
        listPatients.append(lobbyPatient)
    return listPatients

