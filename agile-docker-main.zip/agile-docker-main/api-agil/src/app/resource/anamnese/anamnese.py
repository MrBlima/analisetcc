from fastapi_sqlalchemy import db
from fastapi import APIRouter, Request, Depends, HTTPException

from app.schema.anamnese import AnamneseIn, Anamnese
from app.auth.auth import get_current_user, Request, easy_auth
from app.model.model import Anamnese, Patient, Scheduling

router = APIRouter()


@router.post("/anamnese", status_code=200)
def add_anamnese(anamnese: AnamneseIn, token: str = Depends(get_current_user)):
    db_patient = (
        db.session.query(Patient).filter_by(public_id=anamnese.id_patient).first()
    )
    delattr(anamnese, "id_patient")
    if db_patient.fk_anamnese is None:
        obj_anamnese = Anamnese(**anamnese.dict())
        db.session.add(obj_anamnese)
        db.session.commit()
        db_patient.fk_anamnese = obj_anamnese.id
    else:
        anamnese = anamnese.dict()
        for key, value in dict(anamnese).items():
            if value is None:
                del anamnese[key]
        db.session.query(Anamnese).filter_by(id=db_patient.fk_anamnese).update(
            anamnese, synchronize_session=False
        )
    db.session.commit()


@router.get("/anamnese/{id}", status_code=200)
def get_anamnese(id: str, token: str = Depends(get_current_user)):
    db_patient = db.session.query(Patient).filter_by(public_id=id).first()
    obj_anamnese = AnamneseIn.from_orm(db_patient.anamnese)
    return obj_anamnese

@router.put("/finish_anam/{id}", status_code=200)
def finish_anam(id: str, token: str = Depends(get_current_user)):
    try:
        db_patient = db.session.query(Patient).filter_by(public_id=id).first()
        db_sch = db.session.query(Scheduling).filter_by(fk_patient = db_patient.id).order_by(Scheduling.id.desc()).first()
        db_sch.is_present = False
        db.session.commit()
        return db_sch
    except:
        raise HTTPException(412, 'O paciente não está presente!')