from fastapi import FastAPI, APIRouter, Depends
from fastapi_sqlalchemy import db
from datetime import datetime

from app.auth.auth import get_current_user, Request, easy_auth
from app.schema.schedule import SchedulingIn, SchedulingOut, SchedulingEdit
from app.model.model import Scheduling, Insurance, Patient

router = APIRouter()


@router.post("/scheduling", status_code=201)
def add_scheduling(schedule: SchedulingIn, token: str = Depends(get_current_user)):
    schedule = schedule.dict()
    if schedule["insurance"] == "0":
        del schedule["insurance"]
        
    else:
        del schedule["custom_insurance"]
        db_insurance = (
            db.session.query(Insurance).filter_by(name=schedule["insurance"]).first()
        )
        schedule["fk_insurance"] = db_insurance.id
        del schedule["insurance"]
    
    db_patient = (
        db.session.query(Patient).filter_by(name=schedule["name"]).first()
    )

    if not db_patient:
        obj_patient = Patient(name = schedule["name"], phone = schedule["phone"])
        db.session.add(obj_patient)
        db.session.commit()
        obj_patient = obj_patient.id
    else:
        obj_patient = db_patient.id
    
    del schedule["name"]

    schedule["fk_patient"] = obj_patient
    date = datetime.strptime(schedule["date_hour"].split(" ")[0], "%d-%m-%Y").date()
    hour = datetime.strptime(schedule["date_hour"].split(" ")[1], "%H:%M").time()
    date_hour = datetime.combine(date, hour)
    schedule["date_hour"] = date_hour

    del schedule["phone"]
    
    obj_schedule = Scheduling(**schedule)
    db.session.add(obj_schedule)
    db.session.commit()

    return obj_schedule


@router.get("/scheduling/{day}")
def get_scheduling(day: str, token: str = Depends(get_current_user)):
    day = datetime.strptime(day, "%d-%m-%Y").date()
    day = day.strftime("%Y-%m-%d")


    day = datetime.strptime(day, "%Y-%m-%d").date()
    hour = datetime.strptime("08:00", "%H:%M").time()
    hourf = datetime.strptime("23:59", "%H:%M").time()
    date_hour = datetime.combine(day, hour)
    date_hourf = datetime.combine(day, hourf)
    db_sch_all = (
        db.session.query(Scheduling).filter(Scheduling.date_hour >= date_hour).filter(Scheduling.date_hour <= date_hourf).all()
    )
    if not db_sch_all:
        return 'No patients'
    lista = []
    
    for db_sch_item in db_sch_all:
        db_patient = SchedulingOut(
            id = db_sch_item.id,
                name = db_sch_item.patient.name,
                phone = db_sch_item.patient.phone,
                scheduling_type = db_sch_item.scheduling_type.name,
                insurance =  db_sch_item.custom_insurance if db_sch_item.custom_insurance else db_sch_item.insurance.name,
                hour = str(db_sch_item.date_hour),
                is_confirmed = db_sch_item.is_confirmed,
                is_present = db_sch_item.is_present,
                last_visit = str(db_sch_item.patient.anamnese.date_update) if db_sch_item.patient.anamnese else 'B'
            )
        lista.append(db_patient)    

    return lista


@router.put('/scheduling', status_code=200)
def edit_schedule(schedule: SchedulingEdit, token: str = Depends(get_current_user)):
    print(schedule)
    if schedule.is_confirmed == None:
        delattr(schedule, "is_confirmed")
    if schedule.is_present == None:
        delattr(schedule, "is_present")
    print(schedule)
    db.session.query(Scheduling).filter_by(id=schedule.id).update(
        schedule.dict(), synchronize_session=False
    )
    db.session.commit()


@router.delete('/scheduling/{id}', status_code=200)
def delete_schedule(id:int, token: str = Depends(get_current_user)):
    db.session.query(Scheduling).filter_by(id = id).delete()
    db.session.commit()

