import uuid
from sqlalchemy import Column, String, Integer, BOOLEAN, DATE, CHAR, ForeignKey, TEXT, TIMESTAMP
from sqlalchemy.orm import relationship

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.sql import func


Base = declarative_base()

#engine = create_engine("postgres://postgres:postgres@localhost:5432/consultorio")


class Patient(Base):
    __tablename__ = 'patient'

    id = Column(Integer, primary_key=True)
    public_id = Column(CHAR(36), default=uuid.uuid4, nullable=False, unique=True, index=True)
    name = Column(String(120), nullable=False)
    birthday = Column(DATE, nullable=True)
    state_civilian = Column(String(20), nullable=True)
    cpf = Column(CHAR(14), nullable=True)
    rg = Column(CHAR(12), nullable=True)
    photo = Column(CHAR(50), nullable=True)
    gender = Column(CHAR(1), nullable=True)
    natural = Column(String(60), nullable=True)
    phone = Column(String(16), nullable=False)
    cellphone = Column(String(16), nullable=True)
    mother = Column(String(120), nullable=True)
    father = Column(String(120), nullable=True)
    facebook = Column(String(60), nullable=True)
    fk_address = Column(Integer, ForeignKey('address.id'), nullable=True, )
    fk_special_cares = Column(Integer, ForeignKey('special_cares.id'), nullable=True)
    fk_anamnese = Column(Integer, ForeignKey('anamnese.id'), nullable=True)
    address = relationship("Address", back_populates="patient", passive_deletes = True)
    special_cares = relationship("Special_Cares", back_populates="patient")
    anamnese = relationship("Anamnese", back_populates="patient")
    scheduling = relationship("Scheduling", back_populates="patient")
    request_exam = relationship("Request_Exam", back_populates="patient")



class Address(Base):
    __tablename__ = 'address'

    id = Column(Integer, primary_key=True)
    street = Column(String(120), nullable=False)
    neighborhood = Column(String(50), nullable=False)
    number = Column(String(5), nullable=True)
    city = Column(String(40), nullable=False)
    state = Column(String(40), nullable=False)
    patient = relationship("Patient", uselist=False, back_populates="address")

    def __init__(self, street, neighborhood, number, city, state):
        self.street = street
        self.neighborhood = neighborhood
        self.number = number
        self.city = city
        self.state = state

class Special_Cares(Base):
    __tablename__ = 'special_cares'

    id = Column(Integer, primary_key=True)
    allergic_substances = Column(String(120), nullable=True)
    ortese = Column(String(90), nullable=True)
    drugs = Column(String(100), nullable=True)
    observations = Column(String(120), nullable=True)
    patient = relationship("Patient", uselist=False, back_populates="special_cares")

    def __init__(self, allergic_substances, ortese, drugs, observations):
        self.allergic_substances = allergic_substances
        self.ortese = ortese
        self.drugs = drugs
        self.observations = observations


class Anamnese(Base):
    __tablename__ = 'anamnese'

    id = Column(Integer, primary_key=True)
    anamnese = Column(TEXT, nullable=True)
    clock_test = Column(Integer, nullable=True)
    minemental = Column(Integer, nullable=True)
    moca = Column(Integer, nullable=True)
    date_update = Column(DATE(),  server_default=func.now(), onupdate=func.now())
    patient = relationship("Patient", uselist=False, back_populates="anamnese")



class Insurance(Base):
    __tablename__ = 'insurance'

    id = Column(Integer, primary_key=True)
    name = Column(String(30), nullable=False)
    scheduling = relationship("Scheduling", back_populates="insurance")

    def __init__(self, name):
        self.name = name


class Scheduling_Type(Base):
    __tablename__ = 'scheduling_type'

    id = Column(Integer, primary_key=True)
    name = Column(String(30), nullable=False)
    scheduling = relationship("Scheduling", back_populates="scheduling_type")

    def __init__(self, name):
        self.name = name


class Scheduling(Base):
    __tablename__ = 'scheduling'

    id = Column(Integer, primary_key=True)
    fk_patient = Column(Integer, ForeignKey('patient.id'), nullable=False)
    fk_scheduling_type = Column(Integer, ForeignKey('scheduling_type.id'), nullable=False)
    fk_insurance = Column(Integer, ForeignKey('insurance.id'), nullable=True)
    custom_insurance = Column(String(40), nullable=True)
    date_hour = Column(TIMESTAMP, nullable=False)
    is_confirmed = Column(BOOLEAN, nullable=False)
    is_present = Column(BOOLEAN, nullable=False)
    patient = relationship("Patient", back_populates="scheduling")
    scheduling_type = relationship("Scheduling_Type", back_populates="scheduling")
    insurance = relationship("Insurance", back_populates="scheduling")

    

class Request_Exam(Base):
    __tablename__ = 'request_exam'

    id = Column(Integer, primary_key=True)
    fk_patient = Column(Integer, ForeignKey('patient.id'), nullable=False)
    date_hour = Column(TIMESTAMP, nullable=False)
    patient = relationship("Patient", back_populates="request_exam")
    exam_type = relationship("Requests_Exams", back_populates="request_exam")

    def __init__(self, fk_patient, date_hour):
        self.fk_patient = fk_patient
        self.date_hour = date_hour


class Exam_Type(Base):
    __tablename__ = 'exam_type'

    id = Column(Integer, primary_key=True)
    name = Column(String(45), nullable=True)
    request_exam = relationship("Requests_Exams", back_populates="exam_type")

    def __init__(self, name):
        self.name = name


class Requests_Exams(Base):
    __tablename__ = 'requests_exams'

    fk_request_exam = Column(Integer, ForeignKey('request_exam.id'), primary_key=True)
    fk_exam_type = Column(Integer, ForeignKey('exam_type.id'), primary_key=True)
    request_exam = relationship("Request_Exam", back_populates="exam_type")
    exam_type = relationship("Exam_Type", back_populates="request_exam")

    def __init__(self, fk_request_exam, fk_exam_type):
        self.fk_request_exam = fk_request_exam
        self.fk_exam_type = fk_exam_type


class Annotation(Base):
    __tablename__ = 'annotation'

    id = Column(Integer, primary_key=True)
    text = Column(String(250), nullable=True)

    def __init__(self, text):
        self.text = text

    #insert into annotation(text) values ('');

class Credentials(Base):
    __tablename__ = 'credentials'
    id = Column(Integer, primary_key=True)
    email = Column(String(50), nullable=False)
    password = Column(String(65), nullable=False)

    def __init__(self, email, password):
        self.email = email
        self.password = password

class Teste(Base):
    __tablename__ = 'teste'
    id = Column(Integer, primary_key=True)